
package Model;

import java.util.ArrayList;
import java.util.List;


public class CinemaModel {
    private List<Movie> movies;
    private List<Ticket> tickets;
    private List<User> users;

    public CinemaModel() {
        movies = new ArrayList<>();
        tickets = new ArrayList<>();
        users = new ArrayList<>();
    }
    
    public List<User> getUsers() {
        return users;
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public List<Ticket> getTickets() {
        return tickets;
    }
}

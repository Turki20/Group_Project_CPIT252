
package Controller;

import Model.*;


public class CancelCommand implements Command{
     private User user;
    private Ticket ticket;

    public CancelCommand(User user, Ticket ticket) {
        this.user = user;
        this.ticket = ticket;
    }

    @Override
    public void execute() {
        if(user.getTickets().contains(ticket)){
        user.cancelTicket(ticket);
        System.out.println("Ticket cancelled: " + ticket.getTicketId());
        user.setWalletFunds(user.getWalletFunds()-ticket.getMovie().getPrice());// to deduct the price from user funds
        }else
            System.out.println("the ticket is already canceld or not exist.");
    }
}

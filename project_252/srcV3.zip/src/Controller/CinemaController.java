
package Controller;

import Model.*;
import View.*;
import java.util.List;


public class CinemaController {
    private CinemaView view;
    private CinemaModel model;

    public CinemaController(CinemaView view, CinemaModel model) {
        this.view = view;
        this.model = model;
    }

    public void displayMovies() {
        List<Movie> movies = model.getMovies();
        view.displayMovies(movies);
    }

    public void bookTicket(User user, Ticket ticket) {
        TicketManager ticketManager = new TicketManager();
        Command bookingCommand = new BookingCommand(user, ticket);
        ticketManager.executeCommand(bookingCommand);
    }

    public void cancelTicket(User user, Ticket ticket) {
        TicketManager ticketManager = new TicketManager();
        Command cancelCommand = new CancelCommand(user, ticket);
        ticketManager.executeCommand(cancelCommand);
    }
    
    public void displayAllTickets(){
        List<User> users = model.getUsers();
        view.displayAllTickets(users);
    }
}

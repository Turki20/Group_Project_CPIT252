
package Controller;

import Model.*;


public class BookingCommand implements Command{
    private User user;
    private Ticket ticket;

    public BookingCommand(User user, Ticket ticket) {
        this.user = user;
        this.ticket = ticket;
    }

    @Override
    public void execute() { // check the command pattern 
        user.bookTicket(ticket);
        System.out.println("Ticket booked: " + ticket.getTicketId());
    }
}

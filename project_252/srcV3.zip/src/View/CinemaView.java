package View;

import Model.*;

import java.util.List;

public class CinemaView {

    public void displayMovies(List<Movie> movies) {
        System.out.println("Available Movies:");
        for (Movie movie : movies) {
            System.out.println(movie.getTitle() + " - " + movie.getType() + " - " + movie.getGenre() + " - duration: " + movie.getDuration() + " - Available Seats: " + movie.getSeats() + " - Price: " + movie.getPrice() + "$");
        }
    }

    public void displayTickets(List<Ticket> tickets) {
        System.out.println("Your Tickets:");
        for (Ticket ticket : tickets) {
            System.out.println("Ticket ID: " + ticket.getTicketId() + " for movie: " + ticket.getMovie().getTitle());
        }
    }

    public void displayAllTickets(List<User> users) {
        System.out.println("All tickits:");
        for (User user : users) {
            List<Ticket> hisTicket = user.getTickets();
            if (hisTicket.size() > 0) {
                System.out.println("User : " + user.getName() + "Email: " + user.getEmail());
                for (Ticket ticket : hisTicket) {
                    System.out.println("\tTicket ID: " + ticket.getTicketId() + " for movie: " + ticket.getMovie().getTitle());
                }
            }
        }
    }
}

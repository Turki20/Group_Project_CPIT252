package Controller;

import Model.*;
import View.*;

import java.util.List;

public class CinemaController {
    private final CinemaView view;
    private final CinemaModel model;
    private Command command;

    public CinemaController(CinemaView view, CinemaModel model) {
        this.view = view;
        this.model = model;
    }

    // إضافة مدير
    public void addAdmin(int userId, String name, String email) {
        model.addUser(new Admin(userId, name, email));
    }

    // إضافة مستخدم
    public void addUser(int userId, String name, String email) {
        model.addUser(new User(userId, name, email));
    }

    // إضافة فيلم
    public void addMovie(String type, String title, String genre, int duration, double price, int seats) {
        try {
            Movie movie = MovieFactory.createMovie(type, title, genre, duration, price, seats);
            model.addMovie(movie);
            view.displayMessage("Movie added successfully: " + title);
        } catch (IllegalArgumentException e) {
            view.displayMessage("Error adding movie: " + e.getMessage());
        }
    }

    // حذف فيلم
    public void removeMovie(int index) {
        List<Movie> movies = model.getMovies();
        if (index >= 0 && index < movies.size()) {
            Movie movie = movies.get(index);
            movies.remove(movie);
            view.displayMessage("Movie removed successfully: " + movie.getTitle());
        } else {
            view.displayMessage("Invalid movie index.");
        }
    }

    // عرض جميع الأفلام
    public void displayMovies() {
        List<Movie> movies = model.getMovies();
        view.displayMovies(movies);
    }

    // حجز تذاكر
    public void bookTickets(User user, int movieIndex, int ticketCount) {
        List<Movie> movies = model.getMovies();
        if (movieIndex >= 0 && movieIndex < movies.size()) {
            Movie movie = movies.get(movieIndex);
            if (ticketCount > 0 && ticketCount <= movie.getSeats()) {
                double totalPrice = ticketCount * movie.getPrice();
                if (user.getWalletFunds() >= totalPrice) {
                    for (int i = 0; i < ticketCount; i++) {
                        Ticket ticket = new Ticket(movie, movie.getPrice());
                        command = new BookingCommand(user, ticket);
                        command.execute();
                      //  user.addTicket(ticket); // command pattern 
                    }
                    user.deductFunds(totalPrice);
                    movie.setSeats(movie.getSeats() - ticketCount);
                    view.displayMessage("Tickets booked successfully. Total price: $" + totalPrice);
                } else {
                    view.displayMessage("Insufficient funds. Please add money to your wallet.");
                }
            } else {
                view.displayMessage("Invalid ticket count or not enough seats available.");
            }
        } else {
            view.displayMessage("Invalid movie index.");
        }
    }

    public void displayMessage(String msg){
        view.displayMessage(msg);
    }
    
    public void diplayAdminMinu(){
        view.diplayAdminMinu();
    }
    
    public void diplayUserMinu(){
        view.diplayUserMinu();
    }
    // إلغاء تذكرة
    public void cancelUserTicket(User user, int ticketIndex) {
        List<Ticket> tickets = user.getTickets();
        if (ticketIndex >= 0 && ticketIndex < tickets.size()) {
            Ticket ticket = tickets.get(ticketIndex);
            command = new CancelCommand(user, ticket);
            command.execute();
            //tickets.remove(ticket); // command pattern ---
            Movie movie = ticket.getMovie();
            movie.setSeats(movie.getSeats() + 1); // إرجاع المقعد
            view.displayMessage("Ticket canceled successfully: " + movie.getTitle());
        } else {
            view.displayMessage("Invalid ticket index.");
        }
    }

    // عرض تذاكر المستخدم
    public void displayUserTickets(User user) {
        List<Ticket> tickets = user.getTickets();
        view.displayTickets(tickets);
    }

    // عرض جميع التذاكر
    public void displayAllTickets() {
        List<User> users = model.getUsers();
        for (User user : users) {
            if (!user.getTickets().isEmpty()) {
                view.displayMessage("Tickets for user: " + user.getName());
                view.displayTickets(user.getTickets());
            }
        }
    }

    // الحصول على مستخدم حسب ID
    public User getUserById(int userId) {
        return model.getUsers().stream()
                .filter(user -> user.getUserId() == userId)
                .findFirst()
                .orElse(null);
    }
}

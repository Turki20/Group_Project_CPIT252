
package Controller;

import Model.*;

public class PaymentProxy {
    private double availableFunds ; 

    public boolean processPayment(User user, double amount) {
        availableFunds=user.getWalletFunds();
        System.out.println("Processing payment of $" + amount);

        // Check if sufficient funds are available
        if (amount <= availableFunds) {
            availableFunds -= amount; // Deduct the amount from available funds
            System.out.println("Payment successful. Remaining balance: $" + availableFunds);
            user.setWalletFunds(availableFunds);
            return true;
        } else {
            System.out.println("Payment failed. Insufficient funds. You may need to add some funds to your wallet");
            return false;
        }
    }
}

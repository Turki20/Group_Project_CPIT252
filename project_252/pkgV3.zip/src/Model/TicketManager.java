
package Model;
import Controller.*;


public class TicketManager {

    public void executeCommand(Command command) {
        command.execute();
    }
}

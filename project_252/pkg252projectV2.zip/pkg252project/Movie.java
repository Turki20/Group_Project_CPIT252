
package project_252;


public abstract class Movie {
    protected String title;
    protected String genre;
    protected int duration;
    protected double price;
    public Movie(String title, String genre, int duration,double price) {
        this.title = title;
        this.genre = genre;
        this.duration = duration;
        this.price=price;
    }

    public abstract String getType();

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getDuration() {
        return duration;
    }
}


package project_252;


public class Movie2D extends Movie{
    
    public Movie2D(String title, String genre, int duration, double price) {
        super(title, genre, duration, price);
        
    }

    @Override
    public String getType() {
        return "2D";
    }
}

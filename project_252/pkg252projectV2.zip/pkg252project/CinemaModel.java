
package project_252;

import java.util.ArrayList;
import java.util.List;


public class CinemaModel {
    private List<Movie> movies;
    private List<Ticket> tickets;

    public CinemaModel() {
        movies = new ArrayList<>();
        tickets = new ArrayList<>();
    }

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public List<Ticket> getTickets() {
        return tickets;
    }
}

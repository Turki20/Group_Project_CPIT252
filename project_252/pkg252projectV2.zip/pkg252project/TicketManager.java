
package project_252;


public class TicketManager {

    public void executeCommand(Command command) {
        command.execute();
    }
}


package project_252;


public class Movie3D extends Movie{
    public Movie3D(String title, String genre, int duration, double price) {
        super(title, genre, duration, price);
    }

    @Override
    public String getType() {
        return "3D";
    }
}

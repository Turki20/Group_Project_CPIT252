
package project_252;

import java.util.List;


public class CinemaView {
    public void displayMovies(List<Movie> movies) {
        System.out.println("Available Movies:");
        for (Movie movie : movies) {
            System.out.println(movie.getTitle() + " - " + movie.getType());
        }
    }

    public void displayTickets(List<Ticket> tickets) {
        System.out.println("Your Tickets:");
        for (Ticket ticket : tickets) {
            System.out.println("Ticket ID: " + ticket.getTicketId() + " for movie: " + ticket.getMovie().getTitle());
        }
    }
}

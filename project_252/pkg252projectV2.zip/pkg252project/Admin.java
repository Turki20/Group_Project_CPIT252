
package project_252;


public class Admin extends User{
    public Admin(int userId, String name, String email) {
        super(userId, name, email);
    }

    public void addMovie(String type, String title, String genre, int duration,double price) {
        MovieFactory.createMovie(type, title, genre, duration,price);
        System.out.println("Movie added: " + title);
    }

    public void removeMovie(Movie movie) {
        // Add logic to remove movie from the list (not implemented here).
        System.out.println("Movie removed: " + movie.getTitle());
    }
}

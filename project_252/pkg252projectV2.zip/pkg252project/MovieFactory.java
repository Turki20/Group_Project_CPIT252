
package project_252;


public class MovieFactory {
    public static Movie createMovie(String type, String title, String genre, int duration, double price) {
        switch (type) {
            case "2D":
                return new Movie2D(title, genre, duration, price);
            case "3D":
                return new Movie3D(title, genre, duration, price);
            case "IMAX":
                return new MovieIMAX(title, genre, duration, price);
            default:
                throw new IllegalArgumentException("Invalid movie type");
        }
    }
}

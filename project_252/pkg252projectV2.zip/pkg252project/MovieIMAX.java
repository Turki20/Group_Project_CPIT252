
package project_252;


public class MovieIMAX extends Movie{
    public MovieIMAX(String title, String genre, int duration, double price) {
        super(title, genre, duration,price);
    }

    @Override
    public String getType() {
        return "IMAX";
    }
}

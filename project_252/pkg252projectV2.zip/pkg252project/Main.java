
package project_252;


import java.util.Scanner;

import java.util.InputMismatchException;
import java.util.Scanner;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Initialize Model, View, and Controller
        CinemaModel model = new CinemaModel();
        CinemaView view = new CinemaView();
        CinemaController controller = new CinemaController(view, model);
        PaymentProxy paymentProxy = new PaymentProxy();

        // Create sample users (admin and regular users) and add movies
        Admin admin = new Admin(1, "Admin User", "admin@example.com");
        User user1 = new User(2, "John Doe", "john@example.com");
        User user2 = new User(3, "Jane Smith", "jane@example.com");

        // Add some sample movies
        model.addMovie(MovieFactory.createMovie("2D", "Avatar", "Sci-Fi", 162,15.00));
        model.addMovie(MovieFactory.createMovie("3D", "Avengers", "Action", 143,20.00));
        model.addMovie(MovieFactory.createMovie("IMAX", "Interstellar", "Sci-Fi", 169, 25.00));

        // Array of users for login purposes
        User[] users = {admin, user1, user2};
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            try {
                // Prompt for login
                System.out.println("\n--- Welcome to the Cinema Ticket Booking System ---");
                System.out.print("Please enter your User ID to log in: ");
                int userId = scanner.nextInt();
                scanner.nextLine(); // Consume the leftover newline

                // Find user by ID
                User loggedInUser = null;
                for (User user : users) {
                    if (user.getUserId() == userId) {
                        loggedInUser = user;
                        break;
                    }
                }

                if (loggedInUser == null) {
                    System.out.println("User not found. Please try again.");
                    continue;
                }

                // Admin or User Menu based on User Role
                if (loggedInUser instanceof Admin) {
                    System.out.println("Welcome, " + loggedInUser.getName() + ". You have admin privileges.");
                    boolean exit = false;
                    while (!exit) {
                        System.out.println("\n--- Admin Menu ---");
                        System.out.println("1. Add a movie");
                        System.out.println("2. Remove a movie");
                        System.out.println("3. Display all movies");
                        System.out.println("4. Logout");
                        System.out.print("Choose an action: ");
                        int choice = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline
                        
                        switch (choice) {
                            case 1:
                                try {
                                    System.out.print("Enter movie type (2D, 3D, IMAX): ");
                                    String type = scanner.nextLine();
                                    System.out.print("Enter movie title: ");
                                    String title = scanner.nextLine();
                                    System.out.print("Enter genre: ");
                                    String genre = scanner.nextLine();
                                    System.out.print("Enter duration in minutes: ");
                                    int duration = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.println("Enter the price of movie ticket");
                                    double price=scanner.nextDouble();
                                    model.addMovie(MovieFactory.createMovie(type, title, genre, duration,price));
                                    System.out.println("Movie added successfully.");
                                } catch (IllegalArgumentException e) {
                                    System.out.println("Error: " + e.getMessage());
                                }
                                break;
                            case 2:
                                view.displayMovies(model.getMovies());
                                System.out.print("Enter the index of the movie to remove: ");
                                int movieIndex = scanner.nextInt();
                                if (movieIndex >= 0 && movieIndex < model.getMovies().size()) {
                                    Movie movieToRemove = model.getMovies().get(movieIndex);
                                    model.getMovies().remove(movieToRemove);
                                    System.out.println("Movie removed: " + movieToRemove.getTitle());
                                } else {
                                    System.out.println("Invalid index.");
                                }
                                break;
                            case 3:
                                controller.displayMovies();
                                System.out.println("\n-------------------\n");
                                break;
                            case 4:
                                exit = true;
                                break;
                            default:
                                System.out.println("Invalid option. Please try again.");
                        }
                    }
                } else {
                    System.out.println("Welcome, " + loggedInUser.getName() + ". You can view movies and book tickets.");
                    boolean exit = false;
                    while (!exit) {
                        System.out.println("\n--- User Menu ---");
                        System.out.println("1. Display all movies");
                        System.out.println("2. Book a ticket");
                        System.out.println("3. View your tickets");
                        System.out.println("4. Cancel a ticket");
                        System.out.println("5. add funds to the account funds");
                        System.out.println("6. show wallet funds");
                        System.out.println("7. Logout");
                        System.out.print("Choose an action: ");
                        int choice = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline
                        
                        switch (choice) {
                            case 1:
                                controller.displayMovies();
                                System.out.println("\n-------------------\n");
                                break;
                            case 2:
                                view.displayMovies(model.getMovies());
                                System.out.print("Enter the index of the movie to book: ");
                                int movieIndex = scanner.nextInt();
                                if (movieIndex >= 0 && movieIndex < model.getMovies().size()) {
                                    Movie selectedMovie = model.getMovies().get(movieIndex);

                                    System.out.println("Available seats: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]");// semulation(not real data we assume seats will always be availble)
                                    System.out.print("Enter the seat number to book: ");
                                    int seatNumber = scanner.nextInt();
                                    
                                    System.out.print("Enter number of tickets: ");
                                    int ticketCount = scanner.nextInt();
                                    
                                    double ticketPrice = selectedMovie.getPrice(); 
                                    double totalPrice = ticketCount * ticketPrice;
                                    
                                    System.out.println("Price per ticket: $" + ticketPrice);
                                    System.out.println("Total price for " + ticketCount + " tickets: $" + totalPrice);

                                    System.out.print("Proceed to payment? (yes/no): ");
                                    String confirmation = scanner.next().toLowerCase();
                                    
                                    if ("yes".equals(confirmation)) {
                                        if (paymentProxy.processPayment(loggedInUser, totalPrice)) {
                                            for (int i = 0; i < ticketCount; i++) {
                                                Ticket ticket = new Ticket(selectedMovie, seatNumber + i, ticketPrice);
                                                controller.bookTicket(loggedInUser, ticket);
                                            }
                                            System.out.println("Tickets booked successfully.");
                                        } else {
                                            System.out.println("Payment failed.");
                                        }
                                    } else {
                                        System.out.println("Booking canceled.");
                                    }
                                } else {
                                    System.out.println("Invalid index.");
                                }
                                break;
                            case 3:
                                view.displayTickets(loggedInUser.getTickets());
                                System.out.println("\n-------------------\n");
                                break;
                            case 4:
                                view.displayTickets(loggedInUser.getTickets());
                                System.out.println("Enter the index of the ticket you want to delete");
                                int index=scanner.nextInt();
                                Ticket ticket=loggedInUser.getTickets().get(index);
                                controller.cancelTicket(loggedInUser, ticket);
                                break;
                            case 5:
                                System.out.println("Enter the amount of funds to add to your account wallte");
                                double funds=scanner.nextDouble();
                                loggedInUser.addFunds(funds);
                                break;
                            case 6:
                                System.out.println("your funds is: "+loggedInUser.getWalletFunds()+"$");
                                break;
                            case 7:
                                exit = true;
                                break;
                            default:
                                System.out.println("Invalid option. Please try again.");
                        }
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter valid input.");
                scanner.next(); // Clear the invalid input
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }
}

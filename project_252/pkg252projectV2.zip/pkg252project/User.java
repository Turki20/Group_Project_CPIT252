
package project_252;

import java.util.ArrayList;
import java.util.List;

public class User {
    protected int userId;
    protected String name;
    protected String email;
    protected List<Ticket> tickets;
    protected double walletFunds=0;

    public User(int userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.tickets = new ArrayList<>();
    }
    
    
    public void addFunds(double funds){
    this.walletFunds+=funds;
        System.out.println(funds+" Added to the wallet successfuly");
        System.out.println("the new wallet funds is: "+walletFunds+"$");
    }

    public void setWalletFunds(double walletFunds) {
        this.walletFunds = walletFunds;
    }

    public double getWalletFunds() {
        return walletFunds;
    }
    

    public void bookTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public void cancelTicket(Ticket ticket) {
        tickets.remove(ticket);        
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}
